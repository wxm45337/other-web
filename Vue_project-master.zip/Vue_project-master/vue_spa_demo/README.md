# Vue Component Demo
Built with `Vue.js` , `vue-router` , with routing , comments , comment folding.<br/>
The build setup uses webpack and the vue-loader plugin.
## Building 
```php
# install:
npm install -g webpack
npm install -g webpack-dev-server
npm install
# watch:
webpack-dev-server --inline --hot
# open the http://loaclhost:8080
```

