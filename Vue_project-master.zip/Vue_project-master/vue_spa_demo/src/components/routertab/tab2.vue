<template>
    <div class="tab tab2">tab2</div>
</template>