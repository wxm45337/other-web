import MongoBase from './mongoBase'
import {demoModel} from './model'

export default new MongoBase(demoModel)