import demo from './demo'
import base from './base'

export default app => {
  demo(app)
  base(app)
}